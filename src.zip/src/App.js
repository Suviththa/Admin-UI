import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import './App.css';
import Dashboard from "./components/admin/Dashboard"; 
import LoginScreen from "./components/admin/pages/LoginScreen";
import ForgotPasswordScreen from "./components/admin/pages/ForgotPasswordScreen";
import ResetPasswordScreen from "./components/admin/pages/ResetPasswordScreen";
import ManageEmployee from "./components/admin/pages/ManageEmployee";
import ManageUser from "./components/admin/pages/ManageUser";
import ManagePayments from "./components/admin/pages/ManagePayments";
import ManageProducts from "./components/admin/pages/ManageProducts";
import AddEmployeeForm from "./components/admin/pages/AddEmployeeForm"
import UpdateEmployee from "./components/admin/pages/UpdateEmployee"
import EmployeePersonal from "./components/admin/pages/EmployeePersonal";
import EmployeeInfo from "./components/admin/pages/EmployeeInfo";
import Categories from "./components/admin/pages/Categories";
import AddCategory from "./components/admin/pages/AddCategory";
import EditCategory from "./components/admin/pages/EditCategory";
import AddProductForm from "./components/admin/pages/AddProductForm";
import EditProducts from "./components/admin/pages/EditProducts";
import CustomizedOrders from "./components/admin/pages/CustomizedOrders";
import ViewCustomizedOrder from "./components/admin/pages/ViewCustomizedOrder";
import EmpInfo from "./components/admin/pages/EmpInfo";
import ProductInfo from "./components/admin/pages/ProductInfo";

const App = () => {
  return (
    <Router>
      <div className="app">
        <Switch>
         
           <Route path='/' exact component={LoginScreen} />
           <Route path='/Dashboard' exact component={Dashboard}/>
          
          <Route path='/ManageEmployee' component={ManageEmployee} />
          {/* <Route path='/EditEmployee/:id' component={EditEmployee} /> */}
          <Route path='/ManageUser' component={ManageUser} />
          <Route path='/ManagePayments' component={ManagePayments} />
          <Route path='/ManageProducts' component={ManageProducts} />
          <Route path='/Categories' component={Categories} />
          <Route path='/AddEmployeeForm' component={AddEmployeeForm} />
          <Route path='/AddCategory' component={AddCategory} />
          <Route path='/AddProductForm' component={AddProductForm} />
          <Route path='/EditCategory' component={EditCategory} />
          <Route path='/EditProducts' component={EditProducts} />
          <Route path='/CustomizedOrders' component={CustomizedOrders} />
          <Route path='/ViewCustomizedOrder' component={ViewCustomizedOrder} />
          <Route path='/EmpInfo' component={EmpInfo} />
          <Route path='/ProductInfo' component={ProductInfo} />
           <Route
            exact
            path="/forgotpassword"
            component={ForgotPasswordScreen} />
          <Route
            exact
            path="/passwordreset/:resetToken"
            component={ResetPasswordScreen}
          /> 

            <Route
            exact
            path="/EmployeePersonal"
            component={EmployeePersonal}
          />
           <Route
            exact
            path="/EmployeeInfo"
            component={EmployeeInfo}
          />
           <Route
            exact
            path="/UpdateEmployee"
            component={UpdateEmployee}
          />  
        </Switch>
      </div>
    </Router>
  );
};

export default App;