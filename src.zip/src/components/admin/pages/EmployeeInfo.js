import "../css/manageEmployee.css";
import { Link } from "react-router-dom";
import usericon from "../../../assets/user1.png"
import axios from "axios";

import React, { useState, useEffect } from "react";

export default function EmployeeInfo() {

    const [employeeList, setEmployeeList] = useState([]);

    const getEmployees = (id) => {
        axios.get("http://localhost:3001/employees").then((response) => {
          setEmployeeList(response.data);
        });
      };
      useEffect(()=>{
        axios.get("http://localhost:3001/load").then((response)=>{
          setEmployeeList(response.data)
        })
      },[])
     

return(
    <div>
           <div className="nav-emp">
           </div>
           <div className="container">
                 <div className="left">
                 <img src={usericon} alt="logo" />
                       <h1>Suviththa Yoganathan</h1>
                       <h2>Sales Manager</h2>
                 </div>
                 <div className="right">
                      <div className="right-box">
                    
                          <br/>
                          <h2>PERSONAL INFORMATION</h2>
                          <div className="details">
                           <div className="details-left">
                          <p>Full Name:  </p>
                          <p>Email Address: </p>
                          <p>NIC No:</p>
                          <p>Address: </p>
                          <p>Phone No: </p>
                          </div>
                          {employeeList.map((record,key) => { 
      return( 
                          <div className="details-right" key={record.id}>
                          <p> {record.name} </p>
                          <p>{record.email} </p>
                          <p>{record.NIC}</p>
                          <p>{record.address} </p>
                          <p>{record.phone_no}</p>
                          </div>
                          )
                        })}
                          

                          </div>

                          <h2>JOB INFORMATION</h2>
                          <div className="details">
                           <div className="details-left">
                          <p>Employee ID:</p>
                          <p>Role:</p>
                          <p>Job Start Date:</p>
                          </div>
                          <div className="details-right">
                          <p> Suviththa Yoganathan </p>
                          <p>Email Address: </p>
                          <p>NIC No:</p>
                          </div>

                          </div>
                          
                      </div>
                 </div>
           </div>
        </div>
)

}