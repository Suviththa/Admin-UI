import "../css/manageEmployee.css";
import { Link } from "react-router-dom";

import { Component } from 'react';

class CustomerView extends Component{

    searchArray =[];

  constructor(props) {
    super(props);
    this.state = {
      records: [],
      isLoaded: false,
    };
  }

  componentDidMount()  {
    fetch('http://localhost:3001/loadCustomer')
      .then(res => res.json())
      .then(result => {
        this.setState({
          isLoaded: true,
          records: result
        });
      });
  }

 

//   onChangeHandler(e){
//       console.log(e.target.value);
//       let newArray = this.searchArray.filter((d)=>{
//           console.log(d);
//           let searchValue = d.name.toLowerCase();
//           return searchValue.indexOf(e.target.value !== -1
//     );
//       this.setState({records:newwArray})
//   }
    render(){
      const { records } = this.state;
     return(
        <div className="employee-main">
        <h2>Customers Information </h2>
        <div className="main-box">
          <div className="add-btn">
               <input type='text' placeholder="Search.."/>
           
            <table class="table-border-shadow">
              <thead class="thead-dark">
                <tr>
                  <th scope="col">#</th>
                  <th scope="col">Full Name</th>
                  <th scope="col">Email</th>
                  <th scope="col">Address</th>
                  <th scope="col">Phone No</th>
                  <th scope="col">Points</th>
                  <th scope="col">Order Frequency</th>
                  
                </tr>
              </thead>
             <tbody>
                 {this.state.records.map((record)=>{
                   return(
                    <tr>
                    <th scope="row">{record.customer_id}</th>
                    <td>{record.name}</td>
                    <td>{record.email}</td>
                    <td>{record.address}</td>
                    <td>{record.phone_no}</td>
                    <td>{record.points}</td>
                    <td>{record.order_frequency}</td>
                  </tr>
                   )
                 })}
                 

                
                  
                
              </tbody> 
            </table>
          </div>
        </div>
         
        </div>
     )
    }
}

export default CustomerView