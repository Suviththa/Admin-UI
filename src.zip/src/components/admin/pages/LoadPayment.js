import "../css/manageEmployee.css";
import { Link } from "react-router-dom";
import SearchIcon from '@material-ui/icons/Search';


export default function LoadPayment() {
    return(
     <div>
      <div className="searchbar">
                   <input type="text"  placeholder="Search"/>
                   <SearchIcon  className='searchicon'/>
                    </div>

        <table class="table-border-shadow">
        <thead class="thead-dark">
          <tr>
            <th scope="col">Payment ID</th>
            <th scope="col">Product Name</th>
            <th scope='col'>Method</th>
            <th scope='col'>Advanced Price</th>
            <th scope='col'>Total Price</th>
            <th scope='col'>Order ID</th>
            <th scope='col'>Status</th>
            
            
            
          </tr>
        </thead>
       <tbody>
           
              <tr>
              <th scope="row">1</th>
              <td>Table</td>
              <td>Cash</td>
              <td>Rs.5000</td>
              <td>Rs.10000</td>
              <td>4</td>
              <td>Paid</td>
            </tr>
            <tr>
              <th scope="row">2</th>
              <td>Sofa</td>
              <td>Cash</td>
              <td>Rs.15000</td>
              <td>Rs.30000</td>
              <td>5</td>
              <td>Paid</td>
            </tr>
            <tr>
              <th scope="row">3</th>
              <td>Cupboard</td>
              <td>Card</td>
              <td>Rs.12000</td>
              <td>Rs.24000</td>
              <td>8</td>
              <td>Pending</td>
            </tr>
            <tr>
              <th scope="row">4</th>
              <td>Dinning</td>
              <td>Card</td>
              <td>Rs.10000</td>
              <td>Rs.20000</td>
              <td>12</td>
              <td>Pending</td>
            </tr>
            <tr>
              <th scope="row">5</th>
              <td>Chair</td>
              <td>Cash</td>
              <td>Rs.400</td>
              <td>Rs.8000</td>
              <td>10</td>
              <td>Paid</td>
            </tr>
            
           

          
            
          
        </tbody> 
      </table>
      </div>
    )
}