import "../css/manageEmployee.css";
import { Link } from "react-router-dom";
import EditCategory from './EditCategory'
import AddCircleIcon from '@material-ui/icons/AddCircle';
import SearchIcon from '@material-ui/icons/Search';
import '../css/popupmodel.css'
import React, { useState, useEffect } from "react";
import HighlightOffIcon from '@material-ui/icons/HighlightOff';
import axios from "axios";

export default function Categories() {
  const [searchTerm,setSearchTerm]=useState("");
  const [categoryList,setCategoryList]=useState([])
 useEffect(()=>{
   axios.get("http://localhost:3001/loadCategory").then((response)=>{
     setCategoryList(response.data)
   })
 },[])

  const [name,setName] = useState("");
  const [date,setDate] = useState("");

  const addCategory = ()=>{
    console.log(name);
     axios.post('http://localhost:3001/AddCategory',{
       name:name,
      date:date,
       
  
      }).then(()=>{
       alert('Category added successfully')
       });
  };

  const [modal, setModal] = useState(false);

  const toggleModal = () => {
    setModal(!modal);
  };

  if(modal) {
    document.body.classList.add('active-modal')
  } else {
    document.body.classList.remove('active-modal')
  }

  const [edit, setEdit] = useState(false);

  const toggleEdit = () => {
    setEdit(!edit);
  };

  if(edit) {
    document.body.classList.add('active-modal')
  } else {
    document.body.classList.remove('active-modal')
  }

  const deleteCategory =(category_id)=>{
    axios.delete(`http://localhost:3001/deleteCategory/${category_id}`).then(()=>{
      alert('Category deleted successfully')
      });
  }

    return(
      <div >
                <div className='box-main'>
                <div className="searchemployeebar">
                   <input type="text"  placeholder="Search" onChange={(e)=>{setSearchTerm(e.target.value);}} />
                   <SearchIcon  className='searchemployeeicon'/>
                </div>
                <Link   className="Addbtn" onClick={toggleModal}><AddCircleIcon style={{marginTop:'5px'}}/> Add New</Link>
               
                </div>
        <table class="table-border-shadow">
        <thead class="thead-dark">
          <tr>
            <th scope="col">ID</th>
            <th scope="col">Category Name</th>
            <th scope='col'>Added Date</th>
            <th >Action</th>
            
          </tr>
        </thead>
       <tbody>
       {categoryList.filter(val=>{if(searchTerm===""){
                       return val;
                     }else if(
                       val.name.toLowerCase().includes(searchTerm.toLowerCase())) 
                     {
                       return val
                     }
                    }).map((record)=>{
                       return(
              <tr>
              <th scope="row">{record.category_id}</th>
              <td>{record.name}</td>
              <td>{record.date}</td>
              <td>
                
                <Link onClick={toggleEdit}
                  class="btn2 btn-outline-primary "
                 >
                  Edit
                </Link>
                <Link 
                  class="btn3 btn-danger" onClick={()=>{deleteCategory(record.category_id)}}>
                  Delete
                </Link>
              </td>
            </tr>
          )
        })}

          
            
          
        </tbody> 
      </table>
      {modal && (
        <div className="modal">
          <div onClick={toggleModal} className="overlay"></div>
          <div className="modal-content">
            <h2>ADD CATEGORY HERE</h2>
            <label>Category Name</label><br/>
            <input type="text" placeholder='Enter Category Name'  className='categoryInput' onChange={(event)=>{setName(event.target.value);}} required /><br/><br/>
            <label>Date</label><br/>
            <input type="Date" placeholder='Enter Date' className='categoryInput' onChange={(event)=>{setDate(event.target.value);}} required /><br/>
            <button type="submit" size='md' className='addbtn' onClick={addCategory}> ADD</button>
            <button className="close-modal" onClick={toggleModal}>
            <HighlightOffIcon/>
            </button>
          </div>
        </div>
      )}
     
     {edit && (
        <div className="modal">
          <div onClick={toggleModal} className="overlay"></div>
          <div className="modal-content">
            <h2>UPDATE CATEGORY HERE</h2>
            <label>Category Name</label><br/>
            <input type="text" placeholder='Enter Category Name'  className='categoryInput' required /><br/><br/>
            <label>Date</label><br/>
            <input type="Date" placeholder='Enter Date' className='categoryInput' required /><br/><br/>
            <button type="submit" size='md' className='addbtn' > Update</button>
            <button className="close-modal" onClick={toggleEdit}>
            <HighlightOffIcon/>
            </button>
          </div>
        </div>
      )}
      </div>
    )
}