import "../css/manageEmployee.css";
import { Link } from "react-router-dom";
import SearchIcon from '@material-ui/icons/Search';

import React, { useState, useEffect } from "react";
import axios from "axios";
import AddCircleIcon from '@material-ui/icons/AddCircle';
import HighlightOffIcon from '@material-ui/icons/HighlightOff';

export default function EmployeeView() {
  const [searchTerm,setSearchTerm]=useState("");
  const [employeeList,setEmployeeList]=useState([])
 useEffect(()=>{
   axios.get("http://localhost:3001/load").then((response)=>{
     setEmployeeList(response.data)
   })
 },[])

 const deleteEmployee =(id)=>{
  axios.delete(`http://localhost:3001/delete/${id}`);
}

const viewEmployee =(id)=>{
  axios.get(`http://localhost:3001/view/${id}`);
}

const [newName,setNewName]=useState("");

const updateEmployee =(id)=>{
  axios.put("http://localhost:3001/update",{
    id:id,
    name:newName,
  });
  setNewName("")
};

const [modal, setModal] = useState(false);

  const toggleModal = () => {
    setModal(!modal);
  };

  if(modal) {
    document.body.classList.add('active-modal')
  } else {
    document.body.classList.remove('active-modal')
  }




  return(
 
              <div >
                <div className='box-main'>
                <div className="searchemployeebar">
                   <input type="text" onChange={(e)=>{setSearchTerm(e.target.value);}} placeholder="Search"/>
                   <SearchIcon  className='searchemployeeicon'/>
                </div>
                <Link  to='/AddEmployeeForm' className="Addbtn"><AddCircleIcon style={{marginTop:'5px'}}/> Add New</Link>
               
                </div>
               
                <table class="table-border-shadow">
                  <thead class="thead-dark">
                    <tr>
                      <th scope="col">ID</th>
                      <th scope="col">Full Name</th>
                      <th scope="col">Email</th>
                      <th scope="col">Role</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                 <tbody>
                     {employeeList.filter(val=>{if(searchTerm===""){
                       return val;
                     }else if(
                       val.name.toLowerCase().includes(searchTerm.toLowerCase()) || val.email.toLowerCase().includes(searchTerm.toLowerCase())) 
                     {
                       return val
                     }
                    }).map((record)=>{
                       return(
                        <tr>
                        <th scope="row">{record.id}</th>
                        <td>{record.name}</td>
                        <td>{record.email}</td>
                        <td>{record.role}</td>
                        <td>
                          {/* <Link  onClick={()=>{viewEmployee(record.id)}} onClick={toggleModal} className="btn1 btn-primary " >
                            View
                          </Link> */}
                           <Link  to='/EmpInfo' className="btn1 btn-primary " >
                            View
                          </Link>
                          <Link to='/UpdateEmployee' onClick={()=>{updateEmployee(record.id)}}
                            className="btn2 btn-outline-primary "
                           >
                            Edit
                          </Link>
                          <Link onClick={()=>{deleteEmployee(record.id)}}
                            className="btn3 btn-danger"
                           >
                            Delete
                          </Link>
                        </td>
                      </tr>
                       )
                     })}
                     
    
                    
                      
                    
                  </tbody> 
                </table>
                {modal && (
        <div className="modal">
          <div onClick={toggleModal} className="overlay"></div>
          <div className="modal-content">
            <h2>ADD CATEGORY HERE</h2>
            <label>Category Name</label><br/>
            <input type="text" placeholder='Enter Category Name'  className='categoryInput' required /><br/><br/>
            <label>Date</label><br/>
            <input type="Date" placeholder='Enter Date' className='categoryInput'  required /><br/>
            <button type="submit" size='md' className='addbtn' > ADD</button>
            <button className="close-modal" onClick={toggleModal}>
            <HighlightOffIcon/>
            </button>
          </div>
        </div>
      )}
              </div>
           
  )
}