import "../css/manageEmployee.css";
import { Link } from "react-router-dom";
import SearchIcon from '@material-ui/icons/Search';


import React, { useState, useEffect } from "react";
import axios from "axios";


export default function LoadCustomer() {
  const [searchTerm,setSearchTerm]=useState("");
  const [employeeList,setEmployeeList]=useState([])
 useEffect(()=>{
   axios.get("http://localhost:3001/loadcustomer").then((response)=>{
     setEmployeeList(response.data)
   })
 },[])


  return(
              <div>
                   <div className="searchbar">
                   <input type="text" onChange={(e)=>{setSearchTerm(e.target.value);}} placeholder="Search"/>
                   <SearchIcon  className='searchicon'/>
                    </div>
              
              
                <table className="table-border-shadow">
                  <thead className="thead-dark">
                    <tr>
                    <th scope="col">ID</th>
                  <th scope="col">Full Name</th>
                  <th scope="col">Email</th>
                  <th scope="col">Address</th>
                  <th scope="col">Phone No</th>
                  <th scope="col">Points</th>
                  <th scope="col">Order Frequency</th>
                    </tr>
                  </thead>
                 <tbody>
                     {employeeList.filter(val=>{if(searchTerm===""){
                       return val;
                     }else if(
                       val.name.toLowerCase().includes(searchTerm.toLowerCase()) || val.email.toLowerCase().includes(searchTerm.toLowerCase())
                       ||  val.address.toLowerCase().includes(searchTerm.toLowerCase()))
                     {
                       return val
                     }
                    }).map((record)=>{
                       return(
                        <tr>
                         <td scope="row">{record.customer_id}</td>
                         <td>{record.name}</td>
                          <td>{record.email}</td>
                        <td>{record.address}</td>
                        <td>{record.phone_no}</td>
                        <td>{record.points}</td>
                        <td>{record.order_frequency}</td>
                        
                      </tr>
                       )
                     })}
                     
    
                    
                      
                    
                  </tbody> 
                </table>
                </div> 
            
  )
}