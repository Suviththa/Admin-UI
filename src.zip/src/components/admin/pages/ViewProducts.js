import "../css/manageEmployee.css";
import { Link } from "react-router-dom";
import EditProducts from './EditProducts'
import AddCircleIcon from '@material-ui/icons/AddCircle';
import SearchIcon from '@material-ui/icons/Search';

export default function ViewProducts() {
    return(
      <div >
      <div className='box-main'>
      <div className="searchemployeebar">
         <input type="text"  placeholder="Search"/>
         <SearchIcon  className='searchemployeeicon'/>
      </div>
      <Link  to='/AddProductForm' className="Addbtn"><AddCircleIcon style={{marginTop:'5px'}}/> Add New</Link>
     
      </div>
        <table class="table-border-shadow">
        <thead class="thead-dark">
          <tr>
            <th scope="col">ID</th>
            <th scope="col">Product Name</th>
            <th scope='col'>Price</th>
            <th scope='col'>Image</th>
            <th scope='col'>Material</th>
            <th scope='col'>Category</th>
            <th >Action</th>
            
          </tr>
        </thead>
       <tbody>
           
              <tr>
              <th scope="row">1</th>
              <td>2</td>
              <td>3</td>
              <td>2</td>
              <td>3</td>
              <td>4</td>
              <td>
              <Link to='/ProductInfo'  class="btn1 btn-primary " >View</Link>
                <Link to='/EditProducts'
                  class="btn2 btn-outline-primary "
                 >
                  Edit
                </Link>
                <Link 
                  class="btn3 btn-danger"
                 >
                  Delete
                </Link>
              </td>
            </tr>
            
           

          
            
          
        </tbody> 
      </table>
      </div>
    )
}