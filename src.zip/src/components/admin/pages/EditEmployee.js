import { Link } from "react-router-dom";
import clsx from 'clsx';
import { useHistory,useParams } from "react-router-dom";


import React, { useState, useEffect } from "react";
import axios from "axios";
import usericon from "../../../assets/user1.png"


import "../css/manageEmployee.css"
import "../css/addEmployee.css"

import { makeStyles } from '@material-ui/core/styles';
import CssBaseline from '@material-ui/core/CssBaseline';
import Drawer from '@material-ui/core/Drawer';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import List from '@material-ui/core/List';
import Typography from '@material-ui/core/Typography';
import Divider from '@material-ui/core/Divider';
import IconButton from '@material-ui/core/IconButton';
import Badge from '@material-ui/core/Badge';
import Paper from '@material-ui/core/Paper';
import MenuIcon from '@material-ui/icons/Menu';
import ChevronLeftIcon from '@material-ui/icons/ChevronLeft';
import NotificationsIcon from '@material-ui/icons/Notifications';


import { mainListItems, Logout } from '../listItems';


const drawerWidth = 240;

const useStyles = makeStyles((theme) => ({
  root: {
    display: 'flex',
  },
  toolbar: {
    paddingRight: 24, // keep right padding when drawer closed
  },
  toolbarIcon: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'flex-end',
    padding: '0 8px',
    ...theme.mixins.toolbar,
  },
  appBar: {
    zIndex: theme.zIndex.drawer + 1,
    transition: theme.transitions.create(['width', 'margin'], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
  },
  appBarShift: {
    marginLeft: drawerWidth,
    width: `calc(100% - ${drawerWidth}px)`,
    transition: theme.transitions.create(['width', 'margin'], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  },
  menuButton: {
    marginRight: 36,
  },
  menuButtonHidden: {
    display: 'none',
  },
  title: {
    flexGrow: 1,
    fontSize:40,
    fontWeight:600,
  },
  userimage : {
    height: 60,
    width: 60,
    borderRadius:100,
    borderColor:'rgb(37, 37, 94)',
    backgroundColor:'rgb(37, 37, 94)',

  },
  drawerPaper: {
    position: 'relative',
    whiteSpace: 'nowrap',
    width: drawerWidth,
    transition: theme.transitions.create('width', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  },
  drawerPaperClose: {
    overflowX: 'hidden',
    transition: theme.transitions.create('width', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    width: theme.spacing(7),
    [theme.breakpoints.up('sm')]: {
      width: theme.spacing(9),
    },
  },
  appBarSpacer: theme.mixins.toolbar,
  content: {
    flexGrow: 1,
    height: '100vh',
    overflow: 'auto',
  },
  container: {
    paddingTop: theme.spacing(4),
    paddingBottom: theme.spacing(4),
  },
  paper: {
    padding: theme.spacing(2),
    display: 'flex',
    overflow: 'auto',
    flexDirection: 'column',
  },
  fixedHeight: {
    height: 240,
  },

}));

const styles = {
  side:{
    backgroundColor:'rgb(37, 37, 94)',
  }
};


export default function EditEmployee() {

    let history = useHistory();
    const {id}= useParams();
    //alert(id);

const [name,setName] = useState("");
const [NIC,setNIC] = useState("");
const [email,setEmail] = useState("");
const [phone_no,setPhoneNo] = useState("");
const [job_start_date,setJobStartDate] = useState(0);
const [password,setPassword] = useState(0);
const [address,setAddress] = useState("");
const [role,setRole] = useState("");
const [confirm_password,setConfirmPassword] = useState("");


const [employeeList, setEmployeeList] = useState([]);

const addEmployee = ()=>{
  console.log(name);
   axios.post('http://localhost:3001/create',{
     name:name,
     NIC:NIC,
     email:email,
     phone_no:phone_no,
     job_start_date:job_start_date,
     password:password,
     address:address,
     role:role,
     confirm_password:confirm_password,
     

    }).then(()=>{
       console.log("success");
     });
};

const loadEmployee=async()=>{
const result = await axios.get(`http://localhost:3001/create/${id}`);
setEmployeeList(result.data);
}
useEffect(()=>{
    loadEmployee();
},[]);


  const classes = useStyles();
  const [open, setOpen] = React.useState(true);
  const handleDrawerOpen = () => {
    setOpen(true);
  };
  const handleDrawerClose = () => {
    setOpen(false);
  };
  const fixedHeightPaper = clsx(classes.paper, classes.fixedHeight);

  return (
    <div className={classes.root}>
      <CssBaseline />
      <AppBar position="absolute" className={clsx(classes.appBar, open && classes.appBarShift)}>
        <Toolbar className={classes.toolbar} style={{backgroundColor: 'rgb(37, 37, 94)'}}>
          <IconButton
            edge="start"
            color="primary"
            aria-label="open drawer"
            onClick={handleDrawerOpen}
            className={clsx(classes.menuButton, open && classes.menuButtonHidden)}
          >
            <MenuIcon />
          </IconButton>
          <Typography component="h1" variant="h6" color="white" noWrap className={classes.title}>
            <b>Admin</b>
          </Typography>
          <IconButton color="#fff">
            <Badge badgeContent={4} color="secondary">
              <NotificationsIcon />
            </Badge>
          </IconButton>

          <Paper variant="outlined">
   <img src="https://images.pexels.com/photos/1526814/pexels-photo-1526814.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=500" className={classes.userimage} />
</Paper>
        </Toolbar>
      </AppBar>
      <div style={styles.side}>
      <Drawer
        variant="permanent"
        classes={{
          paper: clsx(classes.drawerPaper, !open && classes.drawerPaperClose),
        }}
        open={open}
      >
        <div className={classes.toolbarIcon} style={{backgroundColor: 'rgb(37, 37, 94)', color:'rgb(37, 37, 94)'}}>
          <IconButton onClick={handleDrawerClose} style={{color:'white'}}>
            <ChevronLeftIcon />
          </IconButton>
        </div>

        <List style={{backgroundColor: 'rgb(37, 37, 94)', color:'white'}}>{mainListItems}</List>

        <List style={{backgroundColor: 'rgb(37, 37, 94)', color:'red'}}>{Logout}</List>

      </Drawer>
      </div>

      <main className={classes.content}>
      <div className="main-page">
    <div className="addemployee-main background-gradient">
    <h2>Edit Employee Details</h2>
    <div className="add-box">
            <div className="addbox-left">
                 <div className="inputfield">
                    <label>Full Name</label><br/>
                    <input type="text"  onChange={(event)=>{setName(event.target.value);}} required />
                 </div>
                <div className="inputfield">
                <label >Employee Role</label><br />
                    <select  onChange={(event)=>{setRole(event.target.value);}} >
                        <option value="" disabled selected>Select Employee Role</option>
                        <option value="Salesmanager">Sales Manager</option>
                        <option value="Deliverymanager">Delivery Manager</option>
                        <option value="Deliveryperson">Delivery Person</option>
                    </select>
                </div>

                 <div className="inputfield">
                    <label >Email address</label><br/>
                    <input type="text" onChange={(event)=>{setEmail(event.target.value);}} required />
                 </div>
                 <div className="inputfield">
                    <label>Address</label><br/>
                    <input type="text" onChange={(event)=>{setAddress(event.target.value);}} required />
                 </div>
                 <div className="inputfield">
                    <label>NIC No</label><br/>
                    <input type="text" onChange={(event)=>{setNIC(event.target.value);}} required />
                 </div>
              </div>
              <div className="addbex-right">
                 <div className="inputfield">
                    <label>Phone No</label><br/>
                    <input type="text" onChange={(event)=>{setPhoneNo(event.target.value);}} required />
                 </div>
                 <div className="inputfield">
                    <label >Job start Date</label><br/>
                    <input type="date"  onChange={(event)=>{setJobStartDate(event.target.value);}} required />
                 </div>
                 <div className="inputfield">
                    <label >Password</label><br/>
                    <input type="text"  onChange={(event)=>{setPassword(event.target.value);}} required />
                 </div>
                 <div className="inputfield">
                    <label >Confirm Password</label><br/>
                    <input type="text"  onChange={(event)=>{setConfirmPassword(event.target.value);}} required />
                 </div>
                
                 <div className="inputfield-button">
                    <input onClick={loadEmployee} value="Submit" className="addbtn" />
                 </div>
                 </div>

                



    </div>

    </div>
    </div>


      </main>
    </div>
  );
}
