import "../css/manageEmployee.css";
import { Link } from "react-router-dom";


export default function LoadOrder() {
    return(
        <table class="table-border-shadow">
        <thead class="thead-dark">
          <tr>
            <th scope="col">ID</th>
            <th scope="col">Product Name</th>
            <th scope='col'>Customer Name</th>
            <th scope='col'>Price</th>
            <th scope='col'>Status</th>
            <th scope='col'>Delivery Date</th>
           
            
            
            
          </tr>
        </thead>
       <tbody>
           
              <tr>
              <th scope="row">1</th>
              <td>2</td>
              <td>3</td>
              <td>2</td>
              <td>3</td>
              <td>4</td>
              
            </tr>
            
           

          
            
          
        </tbody> 
      </table>
    )
}