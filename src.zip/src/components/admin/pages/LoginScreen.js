import img3 from "../../../assets/img3.jpg"
import "../css/LoginScreen.css";
import { Link } from "react-router-dom";
import shop from "../../../assets/shop.png"
import logo from "../../../assets/shoplogo.png"
import WebFont from 'webfontloader';
import React, {useState} from 'react';
import Axios from 'axios';
import Dashboard from "../Dashboard";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";


import * as yup from "yup";

const schema = yup.object().shape({
    email:  yup.string().email().required('Enter the email'),
    password: yup.string().required("Enter the Password"),

})

function Login() {

  const[LoginStatus, setLoginStatus] = useState();

    const { register, handleSubmit, formState: { errors } } = useForm({
        resolver: yupResolver(schema),
    });


  // const [email,setEmail] = useState("")
  // const [password, setPassword] = useState("")

  // const [loginStatus, setLoginStatus] = useState("");

  // const login = ()=>{
  //   axios.post('http://localhost:3001/login',
  //   {email:email,
  //     password:password,
  //   }).then((response)=>{
  //     if(response.data.message){
  //       setLoginStatus(response.data.message)
  //     }
  //     else{
  //      alert('success')
  //     }
  //   });
  // };

  const logininfo = (data) => {
    console.log(data);
    Axios.post("http://localhost:3001/login", {
      
     email: data.email,
      password: data.password,
      
    }).then((response) => {
      console.log(response)
      if (response.data.message) {
        setLoginStatus(response.data.message);
      } else {
        
        // setLoginStatus('Login successfully');
        // //console.log('success');
        if(response.data[0].role='Salesmanager'){
          window.location.href='/dashboard'
        }
      }
     

    });
  };

  return (
   
      
    <div className="content"> 
   
     <div className="left-container">
       <div className="left-container-alpha">
        <img src={img3} alt="img3" className="img3"/>  

       <div className="footer">
            <p> All rights reserved @ EUT Furniture (Pvt) Ltd.<br/>Email: contact@eutfurniture.com</p> 
            <p>Copyright © 2021 Version 1.0 </p> 
        </div>  
       </div>
     </div>
     {/* <div className="logo">
     <h1>EUT </h1>
     </div> */}
    
     <div className="right-container">
     <h1>{LoginStatus}</h1>
         <div className="right-container-flex">
        
             <label className="top">
                 Log in
             </label>

             <form onSubmit={handleSubmit(logininfo)}>
                 <div className="loginfield">
                  <i className="fa fa-user green-color" />
                  <input type="text" placeholder="Username" name='email' {...register('email')}  className="field1" required/>
                  {errors.email?.message && <p className=" errormessage" >{errors.email?.message}</p>}
                 </div>

                 <div className="loginfield">
                  <i className="fa fa-envelope grey-color" />
                  <input type="password" name="password" placeholder="Password" className="field1" {...register('password')} required/>
                  {errors.password?.message && <p className=" errormessage" >{errors.password?.message}</p>}
                 </div>
                     
               <button  type="submit"   className="btnlogin">Log in</button>

                <div class="forget">
                <Link to="/forgotpassword">Forgot Password?</Link>
                </div>
                <div className="mainpage">
                
                </div>
             </form>
         </div>
         
     </div>
     
    </div>
    
  );
}

export default Login;