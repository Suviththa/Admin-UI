import React, { useState, useEffect } from "react";
import clsx from 'clsx';
import axios from "axios";



import { makeStyles } from '@material-ui/core/styles';
import CssBaseline from '@material-ui/core/CssBaseline';
import Drawer from '@material-ui/core/Drawer';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import List from '@material-ui/core/List';
import Typography from '@material-ui/core/Typography';
import IconButton from '@material-ui/core/IconButton';
import Badge from '@material-ui/core/Badge';
import Container from '@material-ui/core/Container';
import Paper from '@material-ui/core/Paper';
import MenuIcon from '@material-ui/icons/Menu';
import AddCircleIcon from '@material-ui/icons/AddCircle';
import ChevronLeftIcon from '@material-ui/icons/ChevronLeft';
import NotificationsIcon from '@material-ui/icons/Notifications';
import Grid from '@material-ui/core/Grid';
import {Button} from 'react-bootstrap';
import Catergory from '../../../assets/category2.jpg'
import Divider from '@material-ui/core/Divider';
import { useForm } from "react-hook-form";
 import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";


import { mainListItems, Logout } from '../listItems';


const drawerWidth = 240;

const useStyles = makeStyles((theme) => ({
  root: {
    display: 'flex',
   
  },
  toolbar: {
    paddingRight: 24, // keep right padding when drawer closed
  },
  toolbarIcon: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'flex-end',
    padding: '0 8px',
    ...theme.mixins.toolbar,
  },
  appBar: {
    zIndex: theme.zIndex.drawer + 1,
    transition: theme.transitions.create(['width', 'margin'], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
  },
  appBarShift: {
    marginLeft: drawerWidth,
    width: `calc(100% - ${drawerWidth}px)`,
    transition: theme.transitions.create(['width', 'margin'], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  },
  menuButton: {
    marginRight: 36,
  },
  menuButtonHidden: {
    display: 'none',
  },
  title: {
    flexGrow: 1,
    fontSize:40,
    fontWeight:600,
  },
  userimage : {
    height: 60,
    width: 60,
    borderRadius:100,
    borderColor:'white',

  },
  drawerPaper: {
    position: 'relative',
    whiteSpace: 'nowrap',
    width: drawerWidth,
    transition: theme.transitions.create('width', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  },
  drawerPaperClose: {
    overflowX: 'hidden',
    transition: theme.transitions.create('width', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    width: theme.spacing(7),
    [theme.breakpoints.up('sm')]: {
      width: theme.spacing(9),
    },
  },
  appBarSpacer: theme.mixins.toolbar,
  content: {
    flexGrow: 1,
    height: '100vh',
    overflow: 'auto',
    
  },
 
  container: {
    paddingTop: theme.spacing(4),
    paddingBottom: theme.spacing(4),
    marginTop:'20px',
    marginLeft:'40px',
  },
  paper: {
    padding: theme.spacing(2),
    display: 'flex',
    overflow: 'auto',
    flexDirection: 'column',
  },
  fixedHeight: {
    height: 'auto',
  },
  addbutton:{
      backgroundColor:'#0000ff',
      height:'50px',
      width:'160px',
      borderRadius:'5px',
      marginRight:'10px',
      textDecoration:'none',
      textAlign:'center',
      paddingTop:'10px'
  },
  addcategorybox:{
    width: '1100px',
    height:'120px',
    backgroundColor: '#fff',
    marginLeft: '30px',
    display:'flex',
    //boxShadow:'5px 1px 2px 2px '
    
  },
  categorybtn:{
      border:0,
      backgroundColor:'#9bddff',
      width:'800px',
      height:'40px',
      marginTop:'40px',
      marginLeft:'30px',
      fontSize:'20px',
      borderRadius:'5px'

  },
  addcategory:{
    height:'40px'
  },
  categoryimage:{
    height:'500px',
    width:'1100px'
},
btn:{
    color:'white',
    fontSize:'18px',
    width:'150px',
    height:'40px',
    backgroundColor:'blue',
    border:'none',
    borderRadius:'5px'
},
addproducts:{
    display:'flex',
},
textareabox:{
    border:'none',
    backgroundColor:'#E1F4FF',
},
formrow:{
 gridTemplateColumns:'1fr 3fr',
 display:'flex'
},
formleft:{
  width:'200px',
  marginTop:'20px',
  marginBottom:'30px',
  marginLeft:'40px'
},
formright:{
  width:'700px',
  marginTop:'20px',
  marginBottom:'30px'
},
formlabel:{
  marginBottom:'32px'
},
formInput:{
height:'40px',
marginBottom:'20px',
width:'750px',
borderRadius:'3px',
borderColor:'#a9a9a9',
border:'1px solid black',
fontSize:'15px'
},
formtextarea:{
  borderRadius:'3px',
  borderColor:'#a9a9a9',
  border:'1px solid black'
}

  

}));

const styles = {
  side:{
    backgroundColor:'rgb(37, 37, 94)',
  }
};

const schema = yup.object().shape({
  name: yup.string().required(),
  email: yup.string().email().required(),
  job_start_date: yup.string().required(),
  address: yup.string().required(),
  role: yup.string().required(),
  NIC: yup.string().max(10, "Must be 10 Characters.").min(10, "Must be 10 Characters."),
  phone_no: yup.string().max(10, "Must be 10 Digits.").min(10, "Must be 10 Digits."),
  password: yup.string().required().min(8).max(15),
  confirm_password: yup.string().when('password', (password, schema) => {
      if (password) return schema.required('Confirm Password is required');
  })
      .oneOf([yup.ref('password')], 'Passwords must match')
})


export default function AddEmployeeForm() {
  const classes = useStyles();
  const [open, setOpen] = React.useState(true);
  const[LoginStatus, setLoginStatus] = useState();

  const { register, handleSubmit, formState: { errors } } = useForm({
    resolver: yupResolver(schema),
});

  // const [name,setName] = useState("");
  // const [NIC,setNIC] = useState("");
  // const [email,setEmail] = useState("");
  // const [phone_no,setPhoneNo] = useState("");
  // const [job_start_date,setJobStartDate] = useState(0);
  // const [password,setPassword] = useState(0);
  // const [address,setAddress] = useState("");
  // const [role,setRole] = useState("");
  // const [confirm_password,setConfirmPassword] = useState("");
  
  
  const addEmployee = (data)=>{
  
     axios.post('http://localhost:3001/register',{
       name:data.name,
       NIC:data.NIC,
       email:data.email,
       phone_no:data.phone_no,
       job_start_date:data.job_start_date,
       password:data.password,
       address:data.address,
       role:data.role,
       confirm_password:data.confirm_password,
       
  
      }).then((response)=>{
        if(response.data.message){
          setLoginStatus(response.data.message)
          // document.getElementById("custmer-signup").reset();
      }
       });
       console.log(data)
  };
  
  

  const handleDrawerOpen = () => {
    setOpen(true);
  };
  const handleDrawerClose = () => {
    setOpen(false);
  };
  const fixedHeightPaper = clsx(classes.paper, classes.fixedHeight);

  return (
    <div className={classes.root}>
      <CssBaseline />
      <AppBar position="absolute" className={clsx(classes.appBar, open && classes.appBarShift)}>
        <Toolbar className={classes.toolbar} style={{backgroundColor: 'rgb(37, 37, 94)'}}>
          <IconButton
            edge="start"
            color="inherit"
            aria-label="open drawer"
            onClick={handleDrawerOpen}
            className={clsx(classes.menuButton, open && classes.menuButtonHidden)}
          >
            <MenuIcon />
          </IconButton>
          <Typography component="h1" variant="h6" color="inherit" noWrap className={classes.title}>
            <b>ADMIN</b>
          </Typography>
          <IconButton color="inherit">
            <Badge badgeContent={4} color="secondary">
              <NotificationsIcon />
            </Badge>
          </IconButton>

          <Paper variant="outlined">
   <img src="https://images.pexels.com/photos/1526814/pexels-photo-1526814.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=500" className={classes.userimage} />
</Paper>
        </Toolbar>
        
      </AppBar>
      <div style={styles.side}>
      <Drawer
        variant="permanent"
        classes={{
          paper: clsx(classes.drawerPaper, !open && classes.drawerPaperClose),
        }}
        open={open}
      >
        <div className={classes.toolbarIcon} style={{backgroundColor: 'rgb(37, 37, 94)', color:'white'}}>
          <IconButton onClick={handleDrawerClose} style={{color:'white'}}>
            <ChevronLeftIcon />
          </IconButton>
        </div>
        <Divider/>
        <List style={{backgroundColor: 'rgb(37, 37, 94)', color:'white'}}>{mainListItems}</List>
        <Divider/>
        <List style={{backgroundColor: 'rgb(37, 37, 94)', color:'red'}}>{Logout}</List>
        <Divider/>
      </Drawer>
      </div>
     
      <main style={{backgroundColor: '#f0f8ff'}} className={classes.content}>
        <div className={classes.appBarSpacer} />
        <Container  maxWidth="lg" className={classes.container}>
        
        <Grid  container spacing={10}>
        {/* Recent Orders */}
        <Grid item xs={11}  direction="row"  >
        
        <div >
           <Paper className={classes.paper}>
               
           <Typography component="h1" variant="h6" color="inherit" align="center" width="100%" noWrap className={classes.title}>
                  <strong> ADD EMPLOYEE DETAILS </strong>
                </Typography>
        
                 
                 
                <form onSubmit={handleSubmit(addEmployee)}>
                <h5 className="d-flex bg-success fc-white  justify-content-center">{LoginStatus}</h5>
                <div className={classes.formrow}>
                 
                  <div className={classes.formleft}>
                  <label className={classes.formlabel}>Full Name : </label><br/><br/><br/>
                  <label className={classes.formlabel}>Employee Role : </label><br/><br/><br/>
                  <label className={classes.formlabel}>Email : </label><br/><br/><br/>
                  <label className={classes.formlabel}>Address : </label><br/><br/><br/>
                  <label className={classes.formlabel}>NIC No : </label><br/><br/><br/>
                  <label className={classes.formlabel}>Phone No : </label><br/><br/><br/>
                  <label className={classes.formlabel}>Job Start Date : </label><br/><br/><br/>
                  <label className={classes.formlabel}>Password : </label><br/><br/><br/>
                  <label className={classes.formlabel}>Confirm Password : </label><br/><br/><br/>
                  </div>
                  <div className={classes.formright}>
                    <div>
                  <input  className={classes.formInput} type="text" name="name" {...register('name')} required /><br/>
                  {errors.name?.message && <p className=" errormessage" >{errors.name?.message}</p>}
                    </div>
                    <div>
                  <select  className={classes.formInput} name="role" {...register('role')}>
                        <option value="" disabled selected >Select Employee Role</option>
                        <option value="Salesmanager">Sales Manager</option>
                        <option value="Deliverymanager">Delivery Manager</option>
                        <option value="Deliveryperson">Delivery Person</option>
                    </select>
                    {errors.role?.message && <p className=" errormessage" >{errors.role?.message}</p>}
                    </div>
                    <div>
                  <input  className={classes.formInput} type="text" name="email"{...register('email')}  required /><br/>
                  {errors.email?.message && <p className=" errormessage" >{errors.email?.message}</p>}
                  </div>
                  <div>
                  <input  className={classes.formInput} type="text" name="address" {...register('address')}  required /><br/>
                   {errors.address?.message && <p className=" errormessage" >{errors.address?.message}</p>}
                  </div>
                  <div>
                  <input  className={classes.formInput} type="text" name="NIC"  {...register('NIC')} required /><br/>
                  {errors.NIC?.message && <p className=" errormessage" >{errors.NIC?.message}</p>}

                  </div>
                    <div>
                  <input  className={classes.formInput} type="text" name="phone_no" {...register('phone_no')} required /><br/>
                  {errors.phone_no?.message && <p className=" errormessage" >{errors.phone_no?.message}</p>}
                  </div>
                  <div>
                  <input  className={classes.formInput} type="date" name="job_start_date" {...register('job_start_date')}  required /><br/>
                  {errors.job_start_date?.message && <p className=" errormessage" >{errors.job_start_date?.message}</p>}
                  </div>
                  <div>
                  <input  className={classes.formInput} type="text"  name="password" {...register('password')}  required /><br/>
                  {errors.password?.message && <p className=" errormessage" >{errors.password?.message}</p>}
                  </div>
                  <div>
                  <input  className={classes.formInput} type="text"  name="confirm_password" {...register('confirm_password')} required /><br/>
                  {errors.confirmpassword?.message && <p className=" errormessage" >{errors.confirmpassword?.message}</p>}
                  </div>
                  
                  </div>
                </div>

                 <div className="inputfield-button"  align='center'>
                    <button type='submit'  className={classes.btn} >Submit</button>
                 </div>
       </form>


  
    
          </Paper>
         </div>
        </Grid>

      </Grid>
        </Container>
      </main>
    </div>
  );
}
