import React from 'react';
import { Link } from 'react-router-dom'
//import { makeStyles, withStyles } from "@material-ui/core/styles";
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';

import DashboardIcon from '@material-ui/icons/Dashboard';
import PersonIcon from '@material-ui/icons/Person';
import LocalShippingIcon from '@material-ui/icons/LocalShipping';
import FormatListNumberedIcon from '@material-ui/icons/FormatListNumbered';
import UndoIcon from '@material-ui/icons/Undo';
import DateRangeIcon from '@material-ui/icons/DateRange';
import PeopleIcon from '@material-ui/icons/People';
import AttachMoneyIcon from '@material-ui/icons/AttachMoney';
import AssignmentIcon from '@material-ui/icons/Assignment';
import PowerSettingsNewIcon from '@material-ui/icons/PowerSettingsNew';
import ManageEmployee from "./pages/ManageEmployee"
import Categories from "./pages/Categories"
import CustomizedOrders from "./pages/CustomizedOrders"

export const mainListItems = (
  <div>
    <ListItem button  component={Link} to="/Dashboard">
      <ListItemIcon style={{color:'white'}}>
        <DashboardIcon />
      </ListItemIcon>
      <ListItemText primary="Dashboard" />
      {/* <strong><h1 >Dashboard</h1></strong> */}
    </ListItem>
    <ListItem button component={Link} to="/ManageUser">
      <ListItemIcon style={{color:'white'}}>
      <PersonIcon />
      </ListItemIcon>
      <ListItemText primary="View Customer" />
    </ListItem>
    <ListItem button component={Link} to="/CustomizedOrders">
      <ListItemIcon style={{color:'white'}} >
        <FormatListNumberedIcon />
      </ListItemIcon>
      <ListItemText primary="Customized Orders" />
    </ListItem>
    <ListItem button component={Link} to="/ManagePayments">
      <ListItemIcon style={{color:'white'}}>
        <AttachMoneyIcon />
      </ListItemIcon>
      <ListItemText primary="Manage Payment" />
    </ListItem>

    <ListItem button component={Link} to="/Categories">
      <ListItemIcon style={{color:'white'}}>
        <UndoIcon />
      </ListItemIcon>
      <ListItemText primary="Categories" />
    </ListItem>

    <ListItem button component={Link} to="/ManageProducts">
      <ListItemIcon style={{color:'white'}}>
        <UndoIcon />
      </ListItemIcon>
      <ListItemText primary="Manage Products" />
    </ListItem>
    <ListItem button component={Link} to="/ManageEmployee">
      <ListItemIcon style={{color:'white'}}>
        <PeopleIcon />
      </ListItemIcon>
      <ListItemText primary="Manage Employees" />
    </ListItem>
    <ListItem button>
      <ListItemIcon style={{color:'white'}}>
        <AssignmentIcon />
      </ListItemIcon>
      <ListItemText primary="Generate Reports" />
    </ListItem>
    <ListItem button>
      <ListItemIcon style={{color:'white'}}>
        <UndoIcon />
      </ListItemIcon>
      <ListItemText primary="Moving Items" />
    </ListItem>
  </div>
);



export const Logout = (
  <div>
    <ListItem button>
      <ListItemIcon >
        <PowerSettingsNewIcon style= {{fontSize:40,color:"red"}}/>
      </ListItemIcon >
      <strong><h1>LOGOUT</h1></strong>
    </ListItem>
  </div>
)