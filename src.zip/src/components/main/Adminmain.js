import "./Adminmain.css"
import Chart from "../charts/Chart"
import Chartnew from "../admin/Chartnew"
import {userData} from "./dummydata"

const Adminmain=()=>{
     return(
         <main>
             <div className="main_container">

                 <div className="main_title">
                 <div className="main_cards">
                     <h2>System Overview</h2>
                     
                 </div>
                </div>

                 <div className="charts">
                   <div className="charts_left">
                     
                            <h1>Recent Orders</h1>
                            <table>
                                <thead>
                                <th>Order Item</th>
                                <th>Customer Name</th>
                                <th>Date</th>
                                <th>Price</th>
                                </thead>
                                <tbody>
                                <tr>
                                    <td>Sofa Set</td>
                                    <td>Asvin Mithush</td>
                                    <td>2021.07.01</td>
                                    <td>Rs.50000</td>
                                </tr>
                                <tr>
                                    <td>Cupboard</td>
                                    <td>Bala</td>
                                    <td>2021.07.04</td>
                                    <td>Rs.25000</td>
                                </tr>
                                <tr>
                                    <td>Bed Set</td>
                                    <td>Mithush</td>
                                    <td>2021.07.02</td>
                                    <td>Rs.30000</td>
                                </tr>
                                <tr>
                                    <td>Table Set</td>
                                    <td>Vinthusan</td>
                                    <td>2021.06.30</td>
                                    <td>Rs.10000</td>
                                </tr>
                                <tr>
                                    <td>Dinning Table</td>
                                    <td>Santhi</td>
                                    <td>2021.07.05</td>
                                    <td>Rs.28000</td>
                                </tr>
                                <tr>
                                    <td>Track</td>
                                    <td>Mathu</td>
                                    <td>2021.07.01</td>
                                    <td>Rs.5000</td>
                                </tr>
                                <tr>
                                    <td>Chairs</td>
                                    <td>Vithu</td>
                                    <td>2021.06.28</td>
                                    <td>Rs.8000</td>
                                </tr>
                                </tbody>
                            </table>
                      
                      
                  </div>  


                  <div className="charts_right">
                     <div className="charts_right_title">
                         <div>
                             <h1>Stats Reports</h1>
                          </div>
                          
                      </div>

                       <div className="charts_right_cards">
                           <div className="card1">
                               <h1>Income</h1>
                               <p>Rs.125,300</p>
                           </div>

                           <div className="card2">
                               <h1>Sales</h1>
                               <p>Rs.100,200</p>
                           </div>

                           <div className="card3">
                               <h1>Customers</h1>
                               <p>3900</p>
                           </div>

                           <div className="card4">
                               <h1>Orders</h1>
                               <p>1881</p>
                           </div>
                       </div>
                   </div>
              </div>
              <Chart data={userData} title="User Analytics" grid dataKey="Active User" />

            </div>
        </main>
     )
}

export default Adminmain